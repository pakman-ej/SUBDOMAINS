#!/bin/bash

# -------- CONFIGURATION --------
DOMAINS_FILE="jasonbourne.txt"
WORDLIST="ethanhunt.txt"
RESOLVERS="vesper.txt"
OUTPUT_FOLDER="shuffledns-results"
MASTER_OUTPUT="benji.txt"
# -------------------------------

mkdir -p "$OUTPUT_FOLDER"
> "$MASTER_OUTPUT"

# Clean DOS line endings
sed -i 's/\r//g' "$DOMAINS_FILE"

# Read domains line by line using for-loop
mapfile -t domains < "$DOMAINS_FILE"
total=${#domains[@]}
count=0

for domain in "${domains[@]}"; do
    count=$((count + 1))
    clean_domain=$(echo "$domain" | sed 's/[^a-zA-Z0-9.-]/_/g')
    output_file="$OUTPUT_FOLDER/$clean_domain.txt"

    echo "[🔍] [$count/$total] Running shuffledns on: $domain"

    tmp_output=$(mktemp)
    shuffledns -d "$domain" -w "$WORDLIST" -r "$RESOLVERS" -silent > "$tmp_output"

    if [[ -s "$tmp_output" ]]; then
        echo "[✅] Found results for $domain"
        cat "$tmp_output" | tee "$output_file" >> "$MASTER_OUTPUT"
        echo "---------------------------------------------" >> "$MASTER_OUTPUT"
    else
        echo "[⚠️] No results for $domain"
    fi

    rm "$tmp_output"
done

echo ""
echo "[✅] FINISHED — All results saved in:"
echo "     📂 $OUTPUT_FOLDER/  (individual files)"
echo "     📄 $MASTER_OUTPUT   (combined full list)"
